package testResult;

import org.junit.Assert;
import org.junit.Assert.*;
import org.junit.Test;

import junit.framework.AssertionFailedError;
import junit.framework.TestResult;

public class TestResultClass extends TestResult {
	public synchronized void addError(Test test, Throwable t) {
		super.addError((junit.framework.Test) test, t);
	}

	public synchronized void addFailure(Test test, AssertionFailedError t) {
		super.addFailure((junit.framework.Test) test, t);
	}

	@Test
	public void test1() {
		Assert.assertEquals(5, 5);
	}

	@Override
	public synchronized void stop() {
		// stop the test here
		
	}
}
