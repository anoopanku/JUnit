package fixtureDemo;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class fixturesDemo {

	@Before
	public void setUp() throws Exception {
		System.out.println("Code for before Method goes here");
	}

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("Code for beforeClass Method goes here");
	}

	@Test
	public void test() {
		System.out.println("Code for TestMethod goes here");
	}

	@Test
	public void test1() {
		System.out.println("Code for TestMethod1 goes here");
	}

	
	@After
	public void tearDown() throws Exception {
		System.out.println("Code for after Method goes here");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("Code for afterClass Method goes here");
	}

}
