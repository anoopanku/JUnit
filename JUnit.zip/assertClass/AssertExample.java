package assertClass;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class AssertExample {

	int num;
	String temp, str;

	@Before
	public void setUp() throws Exception {
		num = 5;
		temp = null;
		str = "Junit is working fine";
	}

	@Test
	public void test() {
		// Checking for Equality
		assertEquals("Junit is working fine", str);
		
		// check for false condition
		assertFalse(num>8);
		
		// check for null value
		assertNull(temp);
		
		// check for true condition
		assertTrue(num==5);
	}

}
