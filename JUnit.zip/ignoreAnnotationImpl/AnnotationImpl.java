package ignoreAnnotationImpl;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class AnnotationImpl {

	static int beforeClassCount = 1;
	static int afterClassCount = 1;
	static int beforeCount = 1;
	static int afterCount = 1;

	@Before
	public void setup() {
		System.out.println("Execution count of Before method is:" + beforeCount++);
	}

	@BeforeClass
	public static void setupClass() {
		System.out.println("Execution count of before class method is: " + beforeClassCount++);
	}

	@Test
	public void test1() {
		System.out.println("\t code for test 1 goes here");
	}

	@Test
	public void test2() {
		System.out.println("\t code for test 2 goes here");
	}

	@Test
	public void test3() {
		System.out.println("\t code for test 3 goes here");
	}

	@Test
	public void test4() {
		System.out.println("\t code for test 4 goes here");
	}
	
	@Ignore
	@Test
	public void test5() {
		System.out.println("\t code for test 5 goes here");
	}

	@After
	public void tearDown() {
		System.out.println("Execution count of After method is " + afterCount++);
	}

	@AfterClass
	public static void tearDownClass() {
		System.out.println("Execution count of AfterClass method is:" + afterClassCount++);
	}

}
