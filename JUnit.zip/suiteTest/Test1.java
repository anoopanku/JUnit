package suiteTest;

import static org.junit.Assert.*;

import org.junit.Test;

public class Test1 {
	String message = "Alex";
	MessageUtil messageUtil=new MessageUtil(message);
	@Test
	public void printingMethod() {
		System.out.println("Inside printingMethod()");
		assertEquals(message,messageUtil.printMessage());
	}

}
