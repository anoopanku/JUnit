package suiteTest;

public class MessageUtil {
	private String message;

	public MessageUtil(String message) {
		this.message = message;
	}

	// print message
	public String printMessage() {
		System.out.println(message);
		return message;
	}

	// add hi to the Message
	public String salutationMessage() {
		message = "hi" + message;
		System.out.println(message);
		return message;
	}
}
