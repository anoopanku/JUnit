package suiteTest;

import static org.junit.Assert.*;

import org.junit.Test;

public class Test2 {
	String message = "Alex";
	MessageUtil messageUtil=new MessageUtil(message);
	@Test
	public void testSalutationMessage() {
		System.out.println("Inside testSalutationMessage()");
		message="hi" + "Alex";
		assertEquals(message,messageUtil.salutationMessage());
	}

}
