package testRunner;

import static org.junit.Assert.*;

import org.junit.Test;

public class Test1 {

	@Test
	public void test() {
		System.out.println("Test 1 is here");
	}

}
