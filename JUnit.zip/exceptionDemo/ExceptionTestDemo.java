package exceptionDemo;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class ExceptionTestDemo {
	int a, b, c;
	@Before
	public void setup() {
		a = 5;
		b = 0;
	}
	
	@Test(expected=java.lang.ArithmeticException.class)
	public void test() {
		c=a/b;
		System.out.println("Division:" +c);
	}

}
