package testExecutionDemo;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

public class testDemo {

	Student s1, s2, s3, s4;

	@Before
	public void setup() {
		System.out.println("------------------------------");
		System.out.println("In Before Method");
		s1 = new Student(1, "Anoop", 36);
		s2 = new Student(2, "Pankaj", 49);
		s3 = new Student(3, "Aakash", 56);
		s4 = new Student(4, "Sudhanshu", 68);
	}
	
	@Test
	public void testPass() {
		System.out.println("in Test passMethod");
		s1.Cal_Grade();
		assertEquals("Pass class", s1.grade);
		s1.Display();
	}

	@Test
	public void testSecond() {
		System.out.println("in Test secondMethod");
		s2.Cal_Grade();
		assertEquals("Pass class", s2.grade);
		s2.Display();
	}

	@Test
	public void testFirst() {
		System.out.println("in Test firstMethod");
		s3.Cal_Grade();
		assertEquals("Second class", s3.grade);
		s3.Display();
	}

	@Test
	public void testDistinction() {
		System.out.println("in Test distinctionMethod");
		s4.Cal_Grade();
		assertEquals("First class", s4.grade);
		s4.Display();
	}
}
