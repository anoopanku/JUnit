package testExecutionDemo;

public class Student {
	int roll_no;
	String name;
	float percentage;
	String grade;

	public Student(int rn, String nm, float p) {
		this.roll_no = rn;
		name = nm;
		percentage = p;
	}

	public String Cal_Grade() {
		if (percentage < 35) {
			grade = "Fail";
		} else if (percentage < 50) {
			grade = "Pass class";
		} else if (percentage < 60) {
			grade = "Second class";
		} else if (percentage < 70) {
			grade = "First class";
		}

		else {
			grade = "Distinction";
		}
		return grade;
	}

	public void Display() {
		System.out.println("Roll Number" + roll_no);
		System.out.println("Name" + name);
		System.out.println("Percentage" + percentage);
		System.out.println("Grade" + grade);

	}

}
