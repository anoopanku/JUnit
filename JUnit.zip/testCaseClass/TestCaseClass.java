package testCaseClass;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import junit.framework.TestCase;

public class TestCaseClass extends TestCase {
	
	@Before
	public void setup() {
	}

	@Test
	public void test() {
		// count the number of test Cases
		System.out.println("No of test case =" + this.countTestCases());

		// test getName
		String name = this.getName();
		System.out.println("Test case name is =" + name);

		// test setName
		this.setName("testNewAdd");
		String newName=this.getName();
		System.out.println("Updated test case Name=" +newName);

	}
	
	// use to close connection
	@Override
	@After
	public void tearDown()
	{
		
	}
}
