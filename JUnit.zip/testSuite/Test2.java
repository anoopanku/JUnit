package testSuite;

import static org.junit.Assert.*;

import org.junit.Test;

public class Test2 {

	@Test
	public void test() {
		System.out.println("Test 2 is here");
	}

}
